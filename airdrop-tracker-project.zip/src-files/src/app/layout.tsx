// ============================================================
// 📁 src/app/layout.tsx — Root layout
// ============================================================

import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Airdrop Tracker — Kelola Airdrop Crypto Kamu! ✨",
  description: "Dashboard anime-themed untuk mengelola dan mengingatkan airdrop crypto. Jangan sampai kelewat deadline!",
  keywords: ["airdrop", "crypto", "tracker", "dashboard", "reminder"],
  icons: {
    icon: "/anime-mascot.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
